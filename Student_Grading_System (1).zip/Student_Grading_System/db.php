<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "grading_db";


$conn = mysqli_connect($servername, $username, $password, $dbname);

?>